<?php $__env->startSection('before-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <section>
        <div class="row">
            <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12">
                    <div class="card card-hover">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-lg-4 col-xl-3">
                                    <img
                                        
                                        src="<?php echo e($item->AccountType->img); ?>"
                                        alt="image"
                                        class="rounded"
                                        width="200"
                                    />
                                </div>
                                <div class="col-md-8 col-lg-8 col-xl-9">
                                    <div class="d-flex justify-content-between m-2">
                                        <h4>Main Account</h4>
                                        <h4 class="balance-ui">Balance</h4>
                                    </div>
                                        <div class="card ">
                                            <div class="p-3 row align-items-center">
                                                <a class="col-sm-8 col-md-6 account-redirect" href="<?php echo e(route('user.account.detail',["account"=>$item->id])); ?>" type="button" data-account="<?php echo e($item->id); ?>">
                                                    <h4>Account Number:</h4>
                                                    <p><?php echo e($item->account_number); ?></p>
                                                </a>
                                                <div class="col-sm-4 col-md-6 text-end">
                                                    <div class="">
                                                        <input type="password" class="form-bl text-end" id="balance" value="<?php echo e($item->BalanceCardAccount->balance); ?>" disabled> <a class="ms-2" type="button" onclick="showBalance(true)"><i class="ti ti-aperture"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(isset($item->DepositAccount)): ?>
                   <?php $__currentLoopData = $item->DepositAccount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <div class="d-flex justify-content-between m-2">
                                <h4>Deposit Account</h4>
                            </div>
                            <div class="card card-hover">
                                <div class="row p-4">
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">ACCOUNT NUMBER:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->account_number); ?></span></div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">PROFIT:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->profit); ?></span></div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">DAYS:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->days); ?></span></div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">METHOD OF INTEREST PAYMENT:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->interest_payment_period); ?></span></div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">CLOSE DATE:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->close_date); ?></span></div>
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">TERMS:  </span> <span class="fs-3 text-bg-light-gray"><?php echo e($da->terms); ?></span></div>
                                    </div>

                                </div>
                            </div>
                        </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div id="deposit">

            </div>
        </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-js'); ?>
    <style>
        .form-bl {
           border: none;
            background: none;
        }
    </style>
    <script>

//        const element = document.querySelector('.account-redirect');
//
//        element.addEventListener('click', () => {
//            const dataAccount = element.getAttribute('data-account');
//            console.log(dataAccount);
//        });




        let bl=false;
        function showBalance(tg){
            bl = tg !== bl;
            $('#balance').attr('type',bl?'text':'password')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/customer/forAuth/account/user_account_list.blade.php ENDPATH**/ ?>