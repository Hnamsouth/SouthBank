<link rel="canonical" href="https://www.wrappixel.com/templates/materialpro/">
<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">

<?php echo $__env->yieldContent('center-css'); ?>
<!-- Custom CSS -->
<link href="../../user_p/dist/css/style.min.css" rel="stylesheet">

<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/user_p/html_u/css.blade.php ENDPATH**/ ?>