<script src="/admin/assets/js/jquery-3.3.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="/admin/assets/js/jquery.nice-select.min.js"></script>
<script src="/admin/assets/js/jquery-ui.min.js"></script>
<script src="/admin/assets/js/jquery.slicknav.js"></script>
<script src="/admin/assets/js/mixitup.min.js"></script>
<script src="/admin/assets/js/owl.carousel.min.js"></script>
<script src="/admin/assets/js/main.js"></script>
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/guest/html/js.blade.php ENDPATH**/ ?>