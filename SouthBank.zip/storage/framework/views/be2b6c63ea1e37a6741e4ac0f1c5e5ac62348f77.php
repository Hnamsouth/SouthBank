<?php $__env->startSection("title","Category List"); ?>

<?php $__env->startSection("content-header"); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Welcome</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
        </div><!-- /.col -->
    </div><!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-center">
                            <h3 class="card-title">DataTable with default features</h3>
                            <button type="button" class="btn btn-default btn-primary" data-toggle="modal" data-target="#modal-lg">
                                Launch Large Modal
                            </button>
                        </div>
                        <div class="modal fade" id="modal-lg">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Large Modal</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form role="form" id="AddCategory" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Name</label>
                                                    <input type="text" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('name')); ?>" name="name" placeholder="Enter Name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Status</label>
                                                    <select name="unit" class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
                                                        <option <?php if(old('status')): ?> selected <?php endif; ?>  value="1">Active</option>
                                                        <option <?php if(!old('status')): ?> selected <?php endif; ?> value="Box">InActive</option>
                                                    </select>
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputFile">Icon</label>
                                                    <div class="input-group">
                                                        <div class="custom-file">
                                                            <input type="file" name="icon" class="custom-file-input <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                        </div>
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="">Upload</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="button" id="add-category"  class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-dark table-striped">
                            <thead>
                            <tr>
                                <th >ID</th>
                                <th >Name</th>
                                <th >Icon</th>
                                <th >Status</th>
                                <th >Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th ><?php echo e($item->id); ?></th>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <img src="<?php echo e($item->icon); ?>" class="img-thumbnail" width="125">
                                    </td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td class="d-flex align-content-center">
                                        <button type="button" class="btn btn-success mr-2">Edit</button>
                                        <button id="btn-delete"  data-dlt="<?php echo e($item->id); ?>" type="button" class="btn-delete btn btn-danger ml-2">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
@endsectio

<?php $__env->startSection('after-js'); ?>
    <script src="../../admin/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="../../admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../../admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
        $('#addCategory').click(()=>{
           $.ajax({
               type:'post',
               url:'/admin/category',
               data:{
                   '_token':<?php echo e(csrf_token()); ?>,
                   data:{
                       'name':$('form input[name]'),
                       'icon':'',
                       'status':1,
                   }
               },
               success:function(response){
                   if(response.status){
                       // reload table
                       let body='';
                       $.each(response.data,(index,value)=>{
                            body+=`
                            <tr>
                               <th >${value.id}</th>
                               <td>${value.name}</td>
                               <td>
                                   <img src="${value.icon}" class="img-thumbnail" width="125">
                               </td>
                               <td>${value.status}</td>
                               <td class="d-flex align-content-center">
                                   <button type="button" class="btn btn-success mr-2">Edit</button>
                                   <button id="btn-delete"  data-dlt="${value.id}" type="button" class="btn-delete btn btn-danger ml-2">Delete</button>
                               </td>
                           </tr>`;
                       })
                   }else{
                   }
               }
           })
        });

        $('#add-category').click(()=>{

            console.log($('form#AddCategory').getChildren());
            console.log($('form#AddCategory input[name="name"]').val())
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before-css'); ?>
    <link rel="stylesheet" href="../../admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../../admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../admin/dist/css/adminlte.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/practice/category.blade.php ENDPATH**/ ?>