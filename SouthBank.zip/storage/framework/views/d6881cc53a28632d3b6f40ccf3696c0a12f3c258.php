<!-- ---------------------------------------------- -->
<script src="../../customer/dist/libs/jquery/dist/jquery.min.js"></script>
<script src="../../customer/dist/libs/simplebar/dist/simplebar.min.js"></script>
<script src="../../customer/dist/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- ---------------------------------------------- -->
<!-- core files -->
<!-- ---------------------------------------------- -->
<script src="../../customer/dist/js/app.min.js"></script>
<script src="../../customer/dist/js/app.init.js"></script>
<script src="../../customer/dist/js/app-style-switcher.js"></script>
<script src="../../customer/dist/js/sidebarmenu.js"></script>

<script src="../../customer/dist/js/custom.js"></script>
<!-- ---------------------------------------------- -->
<!-- current page js files -->
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/customer/html/js.blade.php ENDPATH**/ ?>