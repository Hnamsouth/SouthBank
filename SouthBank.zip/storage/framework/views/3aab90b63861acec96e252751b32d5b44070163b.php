
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

<!-- Css Styles -->

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<link rel="stylesheet" href="/admin/assets/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/elegant-icons.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/nice-select.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/jquery-ui.min.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/owl.carousel.min.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/slicknav.min.css" type="text/css">
<link rel="stylesheet" href="/admin/assets/css/style.css" type="text/css">
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/guest/html/css.blade.php ENDPATH**/ ?>