<div class="container">
    <div class="row">
        <div class="col-lg-3">
            <div class="header__logo">
                <a href="/admin/assets/template/index.html"><img src="/admin/assets/img/logo.png" alt=""></a>
            </div>
        </div>
        <div class="col-lg-6">
            <nav class="header__menu">
                <ul>
                    <li class="active"><a href="/admin/assets/template/index.html">Home</a></li>
                    <li><a href="/admin/assets/template/shop-grid.html">Shop</a></li>
                    <li><a href="#">Pages</a>
                        <ul class="header__menu__dropdown">
                            <li><a href="/admin/assets/template/shop-details.html">Shop Details</a></li>
                            <li><a href="/admin/assets/template/shoping-cart.html">Shoping Cart</a></li>
                            <li><a href="/admin/assets/template/checkout.html">Check Out</a></li>
                            <li><a href="/admin/assets/template/blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                    <li><a href="/admin/assets/template/blog.html">Blog</a></li>
                    <li><a href="/admin/assets/template/contact.html">Contact</a></li>
                </ul>
            </nav>
        </div>
        <div class="col-lg-3">
            <div class="header__cart">
                <ul>
                    <li><a href="#"><i class="fa fa-heart"></i> <span>1</span></a></li>
                    <li><a href="#"><i class="fa fa-shopping-bag"></i> <span>3</span></a></li>
                </ul>
                <div class="header__cart__price">item: <span>$150.00</span></div>
            </div>
        </div>
    </div>
    <div class="humberger__open">
        <i class="fa fa-bars"></i>
    </div>
</div>
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/guest/html/header-container.blade.php ENDPATH**/ ?>