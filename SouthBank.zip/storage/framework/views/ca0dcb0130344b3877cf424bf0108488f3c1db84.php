<?php $__env->startSection('before-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <h3 class="text-center mb-4"> Saving deposit Type</h3>
        <div class="row">
            <?php $__currentLoopData = $sdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card card-hover">
                        <div class="card-body">
                            <h6 class="mb-3"><?php echo e($item->name); ?></h6>
                            <ul class="ms-1">
                                <li class="breadcrumb-item"></li>
                                <li class="breadcrumb-item">
                                    <span class="px-2">Method of receiving Interest:
                                        <?php $__currentLoopData = $item->InterestPaymentMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($i->name); ?> <?php echo e($index===$item->interest_payment_method_count-1?"":','); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    .</span>
                                </li>
                                <?php if($item->increase_principal===0): ?>
                                    <li class="breadcrumb-item">
                                        <span class="px-2"><?php echo e(_('Increase principal, unlimited amount and deposit.')); ?></span>
                                    </li>
                                <?php endif; ?>

                                <li class="breadcrumb-item">
                                    <span class="px-2">Minimum Deposit amount: <?php echo e($item->min_amount*1000000); ?> VND.</span>
                                </li>
                                <li class="breadcrumb-item">
                                    <span class="px-2">Savings term: <?php echo e($item->min_term." tới ".$item->max_term); ?> Month.</span>
                                </li>
                                <li class="breadcrumb-item">
                                    <span class="px-2"><?php echo e($item->withdraw_before_maturity?"Early withdrawal will apply the interest rate without term.":"Can't withdraw before maturity."); ?></span>
                                </li>

                            </ul>
                            <a href="#" class=" btn font-medium text-warning"> More details  <i class="ti ti-file-description fs-4"></i></a>

                            <div class="text-end mt-3">
                                <a href="<?php echo e(route('user.open-saving',['deposit_type'=>$item->id])); ?>" id="clickSubmit" class="btn font-medium btn-primary  px-4" >
                                    <div class="d-flex align-items-center">
                                        Open
                                        <i class="ti ti-send ms-1 fs-4"></i>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <style>
                ul li{
                    margin-bottom: 0.5rem;
                }
            </style>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/customer/forAuth/saving/list_type.blade.php ENDPATH**/ ?>