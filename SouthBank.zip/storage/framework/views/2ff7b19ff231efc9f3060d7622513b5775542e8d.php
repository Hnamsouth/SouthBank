<?php $__env->startSection("title","Api OpenAi"); ?>
<?php $__env->startSection("content-header"); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Api OpenAi Demo</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
        </div><!-- /.col -->
    </div><!-- /.row -->
    <script>
        hljs.initHighlightingOnLoad();

    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("main-content"); ?>
    <div class="">
        <div id="result"></div>
        <div id="result2">









            <pre>
                <code id="html-box"></code>
            </pre>
        </div>

        <div class="position-absolute ">
            <form class="container mx-auto">
                <div class="position-relative ">
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Example textarea</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                    <button id="btn-edits"  class="btn btn-primary position-absolute right-1">Edits</button>
                </div>
            </form>
        </div>








    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('before-js'); ?>
    <script >
        $('#btn-smt').click(function(){
            const prompt=$('#prompt').val();
            $('#result').append(`<div class="text-dark text-right">${prompt}</div>`);
            let data=null;
            $.ajax({
                type: 'POST',
                data:{
                    '_token':"<?php echo e(@csrf_token()); ?>",
                    'prompt':prompt,
                },
                url: '/api/handle/completions',
                success: function (response) {
                    console.log(response);
                    $('#result').append(`<div class="text-blue text-left">${response.choices[0].text}</div>`);

                    let lang = setLang(prompt);
                    html = hljs.highlight(response.choices[0].text, {language: lang}).value
                    $('#html-box').html(html);
                    // $('#html-box').append(`<code>${html}</code>`);
                }
            });
                // $.ajax({
                //     type: "POST",
                //     url: "https://api.openai.com/v1/completions",
                //     // url: "https://api.openai.com/v1/engines/text-davinci-002/jobs",
                //     data: JSON.stringify({
                //         prompt: prompt,
                //         model:"text-davinci-003",
                //         max_tokens: 100,
                //         temperature: 0.5
                //     }),
                //     contentType: "application/json",
                //     headers: {
                //         "Authorization": "Bearer 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"
                //     },
                //     success: function(vl) {
                //         console.log(data);
                //         $('#result').append(`<div class="text-blue text-left">${vl.choices[0].text}</div>`);
                //     }
                // });
        })
        $('#btn-edits').click(function(){
            const input=$('#prompt').val();
            $('#result').append(`<div class="text-dark text-right">${input}</div>`);
            let data=null;
            $.ajax({
                type: "POST",
                data:{
                  "_token":'<?php echo e(@csrf_token()); ?>',
                  "input":  input,
                },
                url: '/api/handle/edits',
                success:function(rp){
                    console.log(rp.choices[0])
                    let lang = setLang(input);
                    html = hljs.highlight(rp.choices[0].text, {language: lang}).value
                    $('#html-box').html(html);
                }
            })
                // $.ajax({
                //     type: "POST",
                //     url: "https://api.openai.com/v1/edits",
                //     data: JSON.stringify({
                //         "input": input,
                //         "model":"code-davinci-edit-001",
                //         // "model":"text-davinci-edit-001",
                //         // max_tokens: 100,
                //         "temperature": 0.5,
                //         "instruction":"return only code",
                //     }),
                //     headers: {
                //         "Content-Type": "application/json",
                //         "Authorization": "Bearer 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"
                //     },
                //     success: function(vl) {
                //         let lang=setLang(prompt);
                //         console.log(vl.choices[0]??"");
                //         html = hljs.highlight(vl.choices[0].text, {language: lang}).value
                //         $('#html-box').html(html);
                //     },
                //     error: function(error) {
                //         console.log(error);
                //     }
                // });
        })

        function setLang(prompt){
            let lang='';
            if(prompt.toLowerCase().indexOf("html")!== -1){
                lang="xml";
            }else if(prompt.toLowerCase().indexOf("python")!== -1){
                lang="python";
            }else if(prompt.toLowerCase().indexOf("c")!== -1){
                lang="C";
            }else if(prompt.toLowerCase().indexOf("c#")!== -1){
                lang="C#";
            }else if(prompt.toLowerCase().indexOf("c++")!== -1){
                lang="C++";
            }else if(prompt.toLowerCase().indexOf("java")!== -1){
                lang="java";
            }else if(prompt.toLowerCase().indexOf("nodejs")!== -1){
                lang="nodejs";
            }else if(prompt.toLowerCase().indexOf("css")!== -1){
                lang="css";
            }else if(prompt.toLowerCase().indexOf("sql")!== -1){
                lang="SQL";
            }else if(prompt.toLowerCase().indexOf("php")!== -1){
                lang="php";
            }else if(prompt.toLowerCase().indexOf("javascript")!== -1||prompt.indexOf("js")!== -1){
                lang="javascript";
            }
            return lang;
        }

        // document.querySelectorAll('div.code').forEach(el => {
        //     // then highlight each
        //     hljs.highlightElement(el);
        // });
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head-js'); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/atom-one-dark.min.css">


    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/OpenAi/form.blade.php ENDPATH**/ ?>