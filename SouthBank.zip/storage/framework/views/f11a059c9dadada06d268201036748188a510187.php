;
<?php $__env->startSection("title","Product List"); ?>;

<?php $__env->startSection("content-header"); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Welcome</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
        </div><!-- /.col -->
    </div><!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
        <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header ">
                        <div class="d-flex justify-content-between align-center">
                            <form action="<?php echo e(route('products-list')); ?>" method="get" class="form-horizontal d-flex">
                                <div class="form-group "  style="margin-right:15px">
                                    <input type="text" class="form-control" value="<?php echo e(app('request')->input('search')); ?>" name="search">
                                </div>
                                <div class="form-group " style="margin-right:15px">
                                    <select name="category_id" class="form-control" >
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                <?php if( app('request')->input('category_id')==$item->id): ?> selected <?php endif; ?>
                                            value="<?php echo e($item->id); ?>">  <?php echo e($item->name); ?>  </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="d-flex" style="margin-right:15px">
                                    <label>From:  </label>
                                    <select name="price_form" class="form-control" >
                                        <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option

                                            value="<?php echo e($item); ?>">  <?php echo e($item); ?>  </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                                <div class="d-flex">
                                    <label>To:  </label>
                                    <select name="price_to" class="form-control select2bs4" >
                                        <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                <?php if( app('request')->input('price_to')==$item): ?> selected <?php endif; ?>
                                            value="<?php echo e($item); ?>">  <?php echo e($item); ?>  </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                                <div class="form-group"  style="margin-right:15px">
                                    <button type="submit"  class="btn btn-primary">Search</button>
                                </div>
                            </form>

                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-lg">
                                Create Product
                            </button>
                        </div>

                        <div class="modal fade" id="modal-lg">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Create Product</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
            <form id="formEdit" role="form"  method="post" enctype="multipart/form-data">  
                                            <?php echo csrf_field(); ?>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Name</label>
                                                    <input type="text" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('name')); ?>" name="name" placeholder="Enter Name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Price</label>
                                                    <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('price')); ?>" name="price"  placeholder="Price...">
                                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Qty</label>
                                                    <input type="number" value="<?php echo e(old('qty')); ?>" name="qty" class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " placeholder="Qty...">
                                                    <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Description</label>
                                                    <textarea  name="description"  class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " placeholder="Description...">
                                                        <?php echo e(old('description')); ?>

                                                    </textarea>
                                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Unit</label>
                                                    <select name="unit" class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
                                                        <option <?php if(old('unit')=='Item'): ?> selected <?php endif; ?>  value="Item">Item</option>
                                                        <option <?php if(old('unit')=='Box'): ?> selected <?php endif; ?> value="Box">Box</option>
                                                    </select>
                                                    <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Status</label>
                                                    <input type="text" value="<?php echo e(old('status')); ?>"  name="status" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " placeholder="Status...">
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Category ID</label>
                                                    <select name="category_id" class="form-control select2bs4" >
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                <?php if(old('category_id')==$item->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($item->id); ?>">  <?php echo e($item->name); ?>  </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <p class="text-danger"><?php echo e($message); ?></p>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="exampleInputFile">Thumbnail</label>
                                                    <a id="link-img" target="_blank">
                                                        <img id="img"  width="50">
                                                    </a>
                                                    <div class="input-group">
                                                        <div class="custom-file">
                                                            <input type="file" name="thumbnail" class="custom-file-input <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                        </div>
                                                        <div class="input-group-append">
                                                            <span class="input-group-text" id="">Upload</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="button" id="add-product"  class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <table id="example1" class="table table-striped table-dark  table-bordered table-hover">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Thumbnail</th>
                                <th scope="col">Price</th>
                                <th scope="col">Qty</th>
                                <th scope="col">Description</th>
                                <th scope="col">Unit</th>
                                <th scope="col">Status</th>
                                <th scope="col">Order Count</th>
                                <th scope="col">Category_Name</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($item->id); ?></th>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <img src="<?php echo e($item->thumbnail); ?>" class="img-thumbnail" width="125">
                                    </td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->unit); ?></td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td><?php echo e($item->Orders->count()); ?></td>
                                    <td><?php echo e($item->Category->name); ?>

                                        <span class="badge bg-info"><?php echo e($item->Category->Products->count()); ?></span>
                                    </td>
                                    <td class="d-flex align-content-center">

                                        <a type="button" href="<?php echo e(route('product-edit2',['product'=>$item->id])); ?>" class="btn btn-success mr-2">Edit2</a>
                                        <button type="button" class="btn btn-default btn-primary EditProduct"  data-edit='<?php echo e($item->id); ?>'>
                                            Edit
                                        </button>
                                        <button type="button" onclick="return confirm('Are you sure')" class="btn btn-danger ml-2 DeleteProduct1 "  data-delete='<?php echo e($index); ?>'>
                                            Delete
                                        </button>


                                        <form action="<?php echo e(route('product-delete',['product'=>$item->id])); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>

                                            <button  type="button" class="btn btn-danger ml-2">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer clearfix">

                    <?php echo $data->appends(app('request')->input())->links("pagination::bootstrap-4"); ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-js'); ?>
    <script src="/admin/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                // "paging": false,
                // "searching": false,
                "responsive": true,
                "autoWidth": false,
            });
            // $('#example2').DataTable({
            //     "paging": true,
            //     "lengthChange": false,
            //     "searching": false,
            //     "ordering": true,
            //     "info": true,
            //     "autoWidth": false,
            //     "responsive": true,
            // });

        });
    </script>
    <script src="../../admin/plugins/sweetalert2/sweetalert2.min.js"></script>
    <script src="../../admin/plugins/toastr/toastr.min.js"></script>
    <script type="text/javascript">
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });

            $('.swalDefaultSuccess').click(function() {
                Toast.fire({
                    icon: 'success',
                    title: 'them san pham thanh cong'
                })
            });
            $('.swalDefaultInfo').click(function() {
                Toast.fire({
                    icon: 'info',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultError').click(function() {
                Toast.fire({
                    icon: 'error',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultWarning').click(function() {
                Toast.fire({
                    icon: 'warning',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultQuestion').click(function() {
                Toast.fire({
                    icon: 'question',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
        });

    </script>
    <script>
        $('.DeleteProduct1').click(function(){
            let index= $(this).data('delete');
            // $('#example1').DataTable().row(index).remove().draw();
            $('#example1').DataTable().ajax.reload();
            // $.ajax({
            //     type:"delete",
            //     url:'/admin/delete-products/'+id,
            //     success: function(rp){
            //     }
            // })
        })
        // add
        $('#add-product').click(()=>{
            const formData = new FormData();
            formData.append('name', $('input[name="name"]').val() );
            formData.append('price', $('input[name="price"]').val());
            formData.append('qty', $('input[name="qty"]').val());
            formData.append('description', $('textarea[name="description"]').val());
            formData.append('unit', $('select[name="unit"]').val());
            formData.append('status', $('input[name="status"]').val());
            formData.append('category_id', $('select[name="category_id"]').val());
            formData.append('_token', "<?php echo e(csrf_token()); ?>");
            formData.append('thumbnail', $('input[type="file"]')[0].files[0]);

            $.ajax({
                type: 'POST',
                data:formData,
                processData: false, // prevent jQuery from automatically processing the data
                contentType: false, // tell jQuery not to set contentType
                url: '/admin/add-product',
                success: function (rp) {
                    if(rp!=null){
                        $('#example1').DataTable().row.add([
                            rp.id,
                            rp.name,
                            `<img src="${rp.thumbnail}" class="img-thumbnail" width="125">`,
                            rp.price,
                            rp.qty,
                            rp.description,
                            rp.unit,
                            rp.status,
                            rp.category_id,
                            `<div>
                                <a type="button" href="<?php echo e(route('product-edit')); ?>${rp.id}" class="btn btn-success mr-2">Edit</a>
                                <a type="button" href="<?php echo e(route('product-edit2')); ?>${rp.id}" class="btn btn-success mr-2">Edit2</a>
                            </div>
                            <form action="<?php echo e(route('product-delete')); ?>?product=${rp.id}" method="post">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button id="btn-delete" type="button" class="btn-delete btn btn-danger ml-2">Delete</button>
                            </form>`
                        ]).draw();
                        alertsAction(true,'Create Product Success');
                    }else{
                        alertsAction(false,'Create Product Failed');
                    }
                }
            })
        })

        // set data edit
        $('.EditProduct').click( function() {
            var editId = $(this).data('edit');
            $.ajax({
                type:'get',
                url:'/admin/list-product/'+editId,
                success: function(response){
                    console.log(response)
                    if(response!=null){
                        $('#formEdit input[name="name"]').val(response.name);
                        $('#formEdit input[name="price"]').val(response.price);
                        $('#formEdit input[name="qty"]').val(response.qty);
                        $('#formEdit input[name="status"]').val(response.status);
                        $('#formEdit textarea[name="description"]').val(response.description);
                        $('#formEdit select[name="category_id"]').val(response.category_id);
                        $('#formEdit select[name="unit"]').val(response.unit);
                        $('#link-img').attr('href',response.thumbnail);
                        $('#img').attr('src',response.thumbnail)

                        $('#modal-lg').modal('show');
                        // alertsAction(true,'Edit Product Success');
                    }else{
                        alertsAction(false,'Edit Product Failed');
                    }

                }
            })
        });
        // handle edit

        function alertsAction(status,content){
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                icon: status?'success':'error',
                title: content
            })
        }

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-css'); ?>
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="../../admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="../../admin/plugins/toastr/toastr.min.css">
    <!-- Google Font: Source Sans Pro -->

    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/practice/product.blade.php ENDPATH**/ ?>