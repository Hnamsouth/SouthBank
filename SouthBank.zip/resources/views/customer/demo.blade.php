@extends('customer.layout')

@section('before-css')
@endsection

@section('main-content')
    <div class="container-fluid">

    </div>
@endsection
