@extends("admin.layout")
@section("title","Admin Template empty")

{{--css--}}
@section('center-css')
    <!--This page CSS -->
@endsection


{{-- main--}}
@section("main-content")

@endsection

{{--js--}}
@section('after-js')
    <!--This page JavaScript -->

@endsection


