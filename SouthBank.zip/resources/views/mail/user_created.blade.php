<div style="margin:0;padding:20px 0;background-color:#f0f0f0">
    <table border="0" cellpadding="0" cellspacing="0" width="640" bgcolor="#ffffff" align="center">
        <tbody><tr>
            <td>
            </td>
        </tr>
        <tr>
            <td style="color:#555555;font-family:Helvetica,Arial,sans-serif;font-size:16px;padding:40px 40px 32px 48px;text-align:left;line-height:20px">
                Kính gửi Quý
                khách <span>HOANG VAN NAM</span>, <br>
                Cảm ơn Quý khách đã tin tưởng và sử dụng dịch vụ của VPBank. Quý khách <span>HOANG VAN NAM</span> vừa hoàn thành đăng ký Bộ tài khoản thanh toán online eKYC, dịch vụ Ngân hàng điện tử VPBank NEO.
                <br>Ngân hàng VPBank xin gửi tới Quý khách thông tin tài khoản như sau:
                <br>
                <span>
                1. Số tài khoản: <span>0967356503</span> - Mở ngày: <span>17/03/2023</span>
            </span>
                <br>
                <span>2. Tên đăng nhập South Bank: <span>{{ $user->username }}</span> </span>
                <br>
                <span>3. Mật khẩu đăng nhập South Bank:{{ $user->real_password }} </span>
                <br>
                <span>
                <span style="padding-left:10px">• Nhận tiền vào tài khoản: Không giới hạn</span>
                <br>
                <span style="padding-left:10px">• Thanh toán/chuyển tiền đi: 10 triệu đồng/tháng; tối đa 10 triệu đồng/ngày</span>
            </span>
                <br>
                <span>
               <u><i>Lưu ý</i></u>: <i>Hạn mức giao dịch mới sẽ được VPBank thông báo tới Quý khách ngay sau khi hồ sơ của Quý khách được xác minh. Vui lòng theo dõi email để cập nhật.</i>
            </span>
                <br>
                <span>
                • Để thay đổi hạn mức giao dịch. Quý khách vui lòng mang theo CMND/CCCD đến chi nhánh của VPBank.
                <br>
Tài khoản thanh toán của Quý khách đã sẵn sàng giao dịch. Để bắt đầu, Quý khách vui lòng tải ứng dụng VPBank NEO tại đây <a href="http://onelink.to/vpbapp" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://onelink.to/vpbapp&amp;source=gmail&amp;ust=1679366386335000&amp;usg=AOvVaw3qIL9VWtkxYu9PqP7sQJpI">http://onelink.to/vpbapp</a> để nhận ngay các ưu đãi:
            </span>
                <br>
                <span>
                • Miễn phí chuyển khoản online trong và ngoài hệ thống VPBank
            </span>
                <br>
                <span>
                • 0 phí quản lý tài khoản và rút tiền tại tất cả ATM trong nước
            </span><br>
                <span>
                • Hàng ngàn quà tặng ưu đãi từ VPBank và đối tác
            </span>

            </td>
        </tr>
        <tr>
            <td bgcolor="#33a948" style="padding:23px 0 32px 48px">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tbody><tr>
                        <td style="color:#ffffff;font-family:Helvetica,Arial,sans-serif;font-size:16px;padding-bottom:18px">
                            Mọi yêu cầu cần được hỗ trợ, Quý khách vui lòng liên hệ cổng chăm sóc khách hàng VPBank:
                        </td>
                    </tr>
                    <tr>
                        <td style="color:#ffffff;font-family:Helvetica,Arial,sans-serif;font-size:14px;padding-top:13px">
                            Điện thoại: (84) 24 392 88880/ 1900545415 <br>
                            Email: <a href="http://customercare@vpbank.com.vn/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://customercare@vpbank.com.vn/&amp;source=gmail&amp;ust=1679366386336000&amp;usg=AOvVaw2kORgqnWym7xbUjVEcKBXG">customercare@vpbank.com.vn/</a> <a href="mailto:chamsockhachhang@vpbank.com.vn" target="_blank">chamsockhachhang@vpbank.com.vn</a>
                        </td>
                    </tr>
                    </tbody></table>
            </td>
        </tr>
        </tbody></table><div class="yj6qo"></div><div class="adL">
    </div></div>
